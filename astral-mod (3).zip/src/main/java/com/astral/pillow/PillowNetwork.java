package com.astral.pillow;

import com.astral.AstralMod;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class PillowNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(AstralMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private PillowNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(0, PillowActionPacket.class,
                PillowActionPacket::encode, PillowActionPacket::decode, PillowActionPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }
}
