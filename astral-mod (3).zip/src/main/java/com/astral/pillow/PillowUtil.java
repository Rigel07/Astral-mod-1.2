package com.astral.pillow;

import com.astral.item.MagicPillowItem;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public final class PillowUtil {
    public static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static final String ID_KEY = "PillowId";

    private PillowUtil() {}

    public static boolean isPillow(ItemStack stack) {
        return stack.getItem() instanceof MagicPillowItem;
    }

    public static boolean worn(LivingEntity entity, EquipmentSlot slot) {
        return isPillow(entity.getItemBySlot(slot));
    }

    /** Cada almohada lleva un identificador propio: es la llave de su bolsillo magico. */
    public static UUID ensureId(ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        if (!tag.hasUUID(ID_KEY)) {
            tag.putUUID(ID_KEY, UUID.randomUUID());
        }
        return tag.getUUID(ID_KEY);
    }
}
