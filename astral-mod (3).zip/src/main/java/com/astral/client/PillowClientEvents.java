package com.astral.client;

import com.astral.AstralMod;
import com.astral.pillow.PillowActionPacket;
import com.astral.pillow.PillowActions;
import com.astral.pillow.PillowNetwork;
import com.astral.pillow.PillowUtil;
import com.astral.registry.ModEffects;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Teclas, ayuda de vuelo y dibujo de la almohada alrededor del jugador. */
@Mod.EventBusSubscriber(modid = AstralMod.MODID, value = Dist.CLIENT)
public final class PillowClientEvents {
    private enum Lie { NONE, SUPINE, PRONE }

    private PillowClientEvents() {}

    // ------------------------------------------------------------------ teclas

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            return;
        }
        while (PillowKeys.SLEEP.consumeClick()) {
            PillowNetwork.CHANNEL.sendToServer(new PillowActionPacket(PillowActions.SLEEP));
        }
        while (PillowKeys.POCKET.consumeClick()) {
            PillowNetwork.CHANNEL.sendToServer(new PillowActionPacket(PillowActions.POCKET));
        }
        while (PillowKeys.RIDE.consumeClick()) {
            PillowNetwork.CHANNEL.sendToServer(new PillowActionPacket(PillowActions.RIDE));
        }

        // montando la nube: al avanzar, subes o bajas hacia donde miras
        if (mc.screen == null && player.hasEffect(ModEffects.PILLOW_RIDE.get())
                && player.getAbilities().flying && player.zza > 0.0F) {
            Vec3 look = player.getLookAngle();
            Vec3 motion = player.getDeltaMovement();
            player.setDeltaMovement(motion.x, motion.y + look.y * 0.12D, motion.z);
        }
    }

    // ---------------------------------------------------------------- dibujado

    private static Lie lie(Player player) {
        if (PillowUtil.worn(player, EquipmentSlot.FEET) && player.hasEffect(ModEffects.PILLOW_RIDE.get())) {
            return Lie.PRONE;
        }
        if (PillowUtil.worn(player, EquipmentSlot.CHEST) && !player.isInWater() && !player.isPassenger()
                && (player.hasEffect(ModEffects.PILLOW_REST.get()) || !player.onGround())) {
            return Lie.SUPINE;
        }
        return Lie.NONE;
    }

    private static float yawOffset(Player player, float partialTick) {
        return 180.0F - Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
    }

    /** Prioridad minima: si otro mod cancela el dibujado no abrimos nada que luego no se cierre. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderPlayerEvent.Pre event) {
        if (event.isCanceled()) {
            return;
        }
        Player player = event.getEntity();
        PoseStack stack = event.getPoseStack();
        MultiBufferSource buffers = event.getMultiBufferSource();
        float partial = event.getPartialTick();
        float time = player.tickCount + partial;
        float psi = yawOffset(player, partial);
        Lie lie = lie(player);

        stack.pushPose();

        // accesorios fijos al suelo de la nube: la nube de montar y las botas de nube
        if (lie == Lie.PRONE) {
            stack.pushPose();
            stack.mulPose(Axis.YP.rotationDegrees(psi));
            stack.translate(0.0D, Math.sin(time * 0.1D) * 0.03D, 0.0D);
            PillowModel.render(stack, buffers, LightTexture.FULL_BRIGHT, 1.5F, 1.4F, 2.4F);
            stack.pushPose();
            stack.translate(0.55D, 0.04D, 0.35D);
            PillowModel.render(stack, buffers, LightTexture.FULL_BRIGHT, 0.85F, 1.3F, 1.0F);
            stack.popPose();
            stack.pushPose();
            stack.translate(-0.5D, 0.05D, -0.45D);
            PillowModel.render(stack, buffers, LightTexture.FULL_BRIGHT, 0.8F, 1.2F, 0.9F);
            stack.popPose();
            stack.popPose();
        } else if (PillowUtil.worn(player, EquipmentSlot.FEET)) {
            stack.pushPose();
            stack.mulPose(Axis.YP.rotationDegrees(psi));
            stack.translate(0.0D, 0.06D + Math.sin(time * 0.12D) * 0.015D, 0.0D);
            PillowModel.render(stack, buffers, event.getPackedLight(), 0.75F, 1.0F, 0.75F);
            stack.popPose();
        }

        // tumbar al jugador: boca abajo sobre la nube, o boca arriba abrazando la almohada
        if (lie != Lie.NONE) {
            float bob = (float) Math.sin(time * 0.09D) * 0.04F;
            stack.mulPose(Axis.YP.rotationDegrees(psi));
            if (lie == Lie.PRONE) {
                stack.translate(0.0D, 0.34D + bob * 0.5D, 0.9D);
                stack.mulPose(Axis.XP.rotationDegrees(-90.0F));
            } else {
                stack.translate(0.0D, 0.40D + bob, -0.9D);
                stack.mulPose(Axis.XP.rotationDegrees(90.0F));
            }
            stack.mulPose(Axis.YP.rotationDegrees(-psi));
        }
    }

    @SubscribeEvent
    public static void onRenderPost(RenderPlayerEvent.Post event) {
        Player player = event.getEntity();
        PoseStack stack = event.getPoseStack();
        MultiBufferSource buffers = event.getMultiBufferSource();
        float partial = event.getPartialTick();
        float time = player.tickCount + partial;
        int light = event.getPackedLight();

        // marco del cuerpo (con la postura de tumbado ya aplicada)
        stack.pushPose();
        stack.mulPose(Axis.YP.rotationDegrees(yawOffset(player, partial)));

        boolean head = PillowUtil.worn(player, EquipmentSlot.HEAD);
        boolean chest = PillowUtil.worn(player, EquipmentSlot.CHEST);
        boolean legs = PillowUtil.worn(player, EquipmentSlot.LEGS);

        if (head) {
            // pegada al cuerpo, como un escudo mullido delante del pecho
            drawChestPillow(stack, buffers, light, time, 0.95F, 0.05D, 0.0F);
        }
        if (chest) {
            // el personaje la abraza: cojin grande sobre el pecho y la tripa
            drawChestPillow(stack, buffers, light, time, 1.2F, 0.0D, 6.0F);
        }
        if (legs) {
            // bolsillo magico: un cojin pequeno que flota junto a la cadera
            stack.pushPose();
            stack.translate(0.62D, 0.95D + Math.sin(time * 0.1D) * 0.05D, 0.12D);
            stack.mulPose(Axis.YP.rotationDegrees((time * 3.0F) % 360.0F));
            stack.mulPose(Axis.ZP.rotationDegrees(14.0F));
            PillowModel.render(stack, buffers, light, 0.5F, 0.6F, 0.5F);
            stack.popPose();
        }
        stack.popPose();
        stack.popPose();   // el nivel abierto en Pre
    }

    private static void drawChestPillow(PoseStack stack, MultiBufferSource buffers, int light, float time,
                                        float scale, double extraForward, float tiltDegrees) {
        stack.pushPose();
        stack.translate(0.0D, 1.0D + Math.sin(time * 0.08D) * 0.02D, -0.34D - extraForward);
        stack.mulPose(Axis.XP.rotationDegrees(90.0F));
        stack.mulPose(Axis.YP.rotationDegrees((float) Math.sin(time * 0.05D) * 4.0F + tiltDegrees));
        PillowModel.render(stack, buffers, light, scale, scale, scale);
        stack.popPose();
    }
}
