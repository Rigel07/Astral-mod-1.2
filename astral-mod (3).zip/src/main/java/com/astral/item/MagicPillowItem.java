package com.astral.item;

import com.astral.pillow.PillowActions;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Almohada Magica: una sola reliquia con cuatro poderes segun la ranura de armadura donde la lleves.
 * (Arrastrala a la ranura de casco, peto, pantalones o botas.)
 */
public class MagicPillowItem extends Item {
    public MagicPillowItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
    }

    /** Se puede llevar en cualquiera de las cuatro ranuras de armadura. */
    @Override
    public boolean canEquip(ItemStack stack, EquipmentSlot slot, Entity entity) {
        return slot.getType() == EquipmentSlot.Type.ARMOR;
    }

    /** Con shift+clic se coloca en la cabeza; para las demas ranuras, arrastrala. */
    @Nullable
    @Override
    public EquipmentSlot getEquipmentSlot(ItemStack stack) {
        return EquipmentSlot.HEAD;
    }

    /** Clic derecho con ella en la mano: abre su bolsillo magico. */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            PillowActions.openPocket(serverPlayer, stack);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.astral.magic_pillow.intro").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC));
        for (String slot : new String[]{"head", "chest", "legs", "feet"}) {
            tooltip.add(Component.translatable("tooltip.astral.magic_pillow." + slot).withStyle(ChatFormatting.GOLD));
            tooltip.add(Component.translatable("tooltip.astral.magic_pillow." + slot + ".desc").withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("tooltip.astral.magic_pillow.keys").withStyle(ChatFormatting.AQUA));
    }
}
